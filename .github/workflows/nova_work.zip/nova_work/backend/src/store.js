import pg from 'pg';
export const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: true } : false, max: 10 });
pool.on('error', err => console.error('Unexpected PostgreSQL pool error', err));
