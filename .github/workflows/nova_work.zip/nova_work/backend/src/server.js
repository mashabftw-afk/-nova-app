import 'dotenv/config';
import http from 'node:http';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import { WebSocketServer } from 'ws';
import { z } from 'zod';
import { pool } from './store.js';
import { authRequired, signToken } from './auth.js';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') ?? false }));
app.use(express.json({ limit: '32kb' }));
app.use('/v1/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'nova-api' }));

const registerSchema = z.object({
  username: z.string().min(3).max(24).regex(/^[a-zA-Z0-9_]+$/),
  displayName: z.string().trim().min(1).max(60),
  password: z.string().min(12).max(128)
});
const loginSchema = z.object({ username: z.string().min(3).max(24), password: z.string().min(1).max(128) });

app.post('/v1/auth/register', async (req, res, next) => {
  try {
    const input = registerSchema.parse(req.body);
    const { hashPassword } = await import('./auth.js');
    const hash = await hashPassword(input.password);
    const result = await pool.query(
      `INSERT INTO users(username, display_name, password_hash)
       VALUES (lower($1), $2, $3)
       RETURNING id, username, display_name, created_at`,
      [input.username, input.displayName, hash]
    );
    const user = result.rows[0];
    res.status(201).json({ user, token: signToken(user.id) });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Username is already taken.' });
    next(e);
  }
});

app.post('/v1/auth/login', async (req, res, next) => {
  try {
    const input = loginSchema.parse(req.body);
    const result = await pool.query('SELECT id, username, display_name, password_hash FROM users WHERE username = lower($1) AND deleted_at IS NULL', [input.username]);
    const user = result.rows[0];
    const { verifyPassword } = await import('./auth.js');
    if (!user || !(await verifyPassword(user.password_hash, input.password))) return res.status(401).json({ error: 'Invalid username or password.' });
    res.json({ user: { id: user.id, username: user.username, displayName: user.display_name }, token: signToken(user.id) });
  } catch (e) { next(e); }
});

app.get('/v1/me', authRequired, async (req, res, next) => {
  try {
    const r = await pool.query('SELECT id, username, display_name, avatar_url, bio, created_at FROM users WHERE id=$1 AND deleted_at IS NULL', [req.user.id]);
    if (!r.rowCount) return res.status(404).json({ error: 'Account not found.' });
    res.json({ user: r.rows[0] });
  } catch (e) { next(e); }
});

app.post('/v1/chats', authRequired, async (req, res, next) => {
  const schema = z.object({ title: z.string().trim().min(1).max(80), memberIds: z.array(z.string().uuid()).max(99).default([]) });
  const client = await pool.connect();
  try {
    const input = schema.parse(req.body);
    await client.query('BEGIN');
    const chat = (await client.query("INSERT INTO chats(chat_type,title,created_by) VALUES ('group',$1,$2) RETURNING id,title,created_at", [input.title, req.user.id])).rows[0];
    const ids = [...new Set([req.user.id, ...input.memberIds])];
    for (const id of ids) await client.query('INSERT INTO chat_members(chat_id,user_id,role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [chat.id, id, id === req.user.id ? 'owner' : 'member']);
    await client.query('COMMIT');
    res.status(201).json({ chat, memberCount: ids.length });
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

app.get('/v1/chats', authRequired, async (req, res, next) => {
  try {
    const r = await pool.query(
      `SELECT c.id,c.chat_type,c.title,c.created_at,
       (SELECT body FROM messages m WHERE m.chat_id=c.id AND m.deleted_at IS NULL ORDER BY m.created_at DESC LIMIT 1) AS last_message
       FROM chats c JOIN chat_members cm ON cm.chat_id=c.id
       WHERE cm.user_id=$1 ORDER BY c.updated_at DESC LIMIT 100`, [req.user.id]);
    res.json({ chats: r.rows });
  } catch (e) { next(e); }
});

app.get('/v1/chats/:chatId/messages', authRequired, async (req, res, next) => {
  try {
    const member = await pool.query('SELECT 1 FROM chat_members WHERE chat_id=$1 AND user_id=$2', [req.params.chatId, req.user.id]);
    if (!member.rowCount) return res.status(403).json({ error: 'Not a member of this chat.' });
    const r = await pool.query(
      `SELECT id,chat_id,sender_id,message_type,body,reply_to_id,created_at,edited_at
       FROM messages WHERE chat_id=$1 AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 50`, [req.params.chatId]);
    res.json({ messages: r.rows.reverse() });
  } catch (e) { next(e); }
});

app.use((err, _req, res, _next) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: 'Invalid request.', details: err.issues.map(x => ({ path: x.path, message: x.message })) });
  console.error(err);
  res.status(500).json({ error: 'Internal server error.' });
});

const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024 });
const clients = new Map(); // userId -> Set<WebSocket>

server.on('upgrade', (req, socket, head) => {
  if (!req.url?.startsWith('/ws?')) return socket.destroy();
  const token = new URL(req.url, 'http://localhost').searchParams.get('token');
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    wss.handleUpgrade(req, socket, head, ws => {
      ws.userId = payload.sub;
      wss.emit('connection', ws);
    });
  } catch { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); }
});

wss.on('connection', ws => {
  const set = clients.get(ws.userId) ?? new Set();
  set.add(ws); clients.set(ws.userId, set);
  ws.on('message', async raw => {
    try {
      const data = JSON.parse(raw.toString());
      if (data.type !== 'message.send' || typeof data.chatId !== 'string' || typeof data.body !== 'string' || !data.body.trim() || data.body.length > 5000) {
        return ws.send(JSON.stringify({ type: 'error', error: 'Invalid message payload.' }));
      }
      const member = await pool.query('SELECT 1 FROM chat_members WHERE chat_id=$1 AND user_id=$2', [data.chatId, ws.userId]);
      if (!member.rowCount) return ws.send(JSON.stringify({ type: 'error', error: 'Not a member of this chat.' }));
      const saved = (await pool.query(
        `INSERT INTO messages(chat_id,sender_id,message_type,body) VALUES($1,$2,'text',$3)
         RETURNING id,chat_id,sender_id,message_type,body,created_at`, [data.chatId, ws.userId, data.body.trim()]
      )).rows[0];
      await pool.query('UPDATE chats SET updated_at=now() WHERE id=$1', [data.chatId]);
      const members = await pool.query('SELECT user_id FROM chat_members WHERE chat_id=$1', [data.chatId]);
      const packet = JSON.stringify({ type: 'message.new', message: saved });
      for (const m of members.rows) for (const client of clients.get(m.user_id) ?? []) if (client.readyState === 1) client.send(packet);
    } catch { if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'error', error: 'Could not process message.' })); }
  });
  ws.on('close', () => {
    const s = clients.get(ws.userId); s?.delete(ws); if (s?.size === 0) clients.delete(ws.userId);
  });
});

const port = Number(process.env.PORT || 8080);
server.listen(port, () => console.log(`NOVA API listening on :${port}`));
