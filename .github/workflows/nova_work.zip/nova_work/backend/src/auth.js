import argon2 from 'argon2';
import jwt from 'jsonwebtoken';
export const hashPassword = password => argon2.hash(password, { type: argon2.argon2id });
export const verifyPassword = (hash, password) => argon2.verify(hash, password);
export const signToken = userId => jwt.sign({}, process.env.JWT_SECRET, { subject: userId, expiresIn: '2h', issuer: 'nova-api', audience: 'nova-client' });
export function authRequired(req, res, next) {
  const value = req.headers.authorization || '';
  const token = value.startsWith('Bearer ') ? value.slice(7) : '';
  try { req.user = jwt.verify(token, process.env.JWT_SECRET, { issuer: 'nova-api', audience: 'nova-client' }); next(); }
  catch { res.status(401).json({ error: 'Authentication required.' }); }
}
