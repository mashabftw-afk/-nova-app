CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 username VARCHAR(24) NOT NULL UNIQUE,
 display_name VARCHAR(60) NOT NULL,
 password_hash TEXT NOT NULL,
 phone_e164 VARCHAR(20) UNIQUE,
 phone_verified_at TIMESTAMPTZ,
 avatar_url TEXT,
 bio VARCHAR(160),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 deleted_at TIMESTAMPTZ
);
CREATE TABLE chats (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 chat_type VARCHAR(12) NOT NULL CHECK(chat_type IN ('direct','group')),
 title VARCHAR(80),
 created_by UUID REFERENCES users(id) ON DELETE SET NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE chat_members (
 chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role VARCHAR(12) NOT NULL DEFAULT 'member' CHECK(role IN ('owner','admin','member')),
 joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 last_read_at TIMESTAMPTZ,
 PRIMARY KEY(chat_id,user_id)
);
CREATE TABLE messages (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 chat_id UUID NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
 sender_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
 message_type VARCHAR(12) NOT NULL DEFAULT 'text' CHECK(message_type IN ('text','image','video','file','system')),
 body TEXT,
 reply_to_id UUID REFERENCES messages(id) ON DELETE SET NULL,
 edited_at TIMESTAMPTZ,
 deleted_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE attachments (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 uploader_id UUID NOT NULL REFERENCES users(id),
 object_key TEXT NOT NULL UNIQUE,
 original_filename VARCHAR(255) NOT NULL,
 mime_type VARCHAR(120) NOT NULL,
 size_bytes BIGINT NOT NULL CHECK(size_bytes >= 0),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE spaces (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 chat_id UUID NOT NULL UNIQUE REFERENCES chats(id) ON DELETE CASCADE,
 description VARCHAR(300),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE space_items (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 space_id UUID NOT NULL REFERENCES spaces(id) ON DELETE CASCADE,
 created_by UUID NOT NULL REFERENCES users(id),
 item_type VARCHAR(12) NOT NULL CHECK(item_type IN ('note','task','link')),
 title VARCHAR(160) NOT NULL,
 content TEXT,
 is_completed BOOLEAN NOT NULL DEFAULT false,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE user_blocks (
 blocker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 blocked_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 PRIMARY KEY(blocker_id,blocked_id),
 CHECK(blocker_id <> blocked_id)
);
CREATE TABLE user_reports (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 reporter_id UUID NOT NULL REFERENCES users(id),
 reported_user_id UUID NOT NULL REFERENCES users(id),
 chat_id UUID REFERENCES chats(id) ON DELETE SET NULL,
 reason VARCHAR(40) NOT NULL,
 details VARCHAR(1000),
 status VARCHAR(12) NOT NULL DEFAULT 'open' CHECK(status IN ('open','reviewing','closed')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CHECK(reporter_id <> reported_user_id)
);
CREATE INDEX idx_chat_members_user ON chat_members(user_id,joined_at DESC);
CREATE INDEX idx_messages_chat_created ON messages(chat_id,created_at DESC);
