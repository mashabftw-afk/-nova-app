# NOVA delivery roadmap

- Milestone A: run Flutter UI and API locally.
- Milestone B: connect Flutter authentication and chat list.
- Milestone C: direct chats, group membership management, receipts, edits, reactions.
- Milestone D: private file storage with signed upload/download URLs.
- Milestone E: phone OTP, push notifications, device/session management.
- Milestone F: Spaces notes/tasks, opt-in AI and translation.
- Milestone G: voice/video via WebRTC.
- Milestone H: subscription billing and entitlement verification.
- Milestone I: load, abuse, privacy and independent security testing before public launch.

A global messaging service needs reliable hosting, moderation, abuse response, backups, observability and privacy operations. Do not launch publicly until these are ready.
