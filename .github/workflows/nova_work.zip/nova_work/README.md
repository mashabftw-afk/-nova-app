# NOVA 1.0 Starter

Cross-platform communication app foundation. Flutter client + Node.js API/WebSocket backend + PostgreSQL schema.

## Honest status
This is a runnable development foundation, not a finished public messaging service. It includes a responsive Flutter UI prototype, backend account endpoints (username/password), authenticated chat APIs, WebSocket message delivery, and database migrations. Phone OTP, push notifications, object storage, AI provider, calls, billing, moderation operations, security review, and production deployment still need provider setup and implementation.

## Requirements
- Flutter 3.22+ / Dart 3.3+
- Node.js 20+
- PostgreSQL 15+
- A computer is recommended for building all platforms. Android-only editing/building is possible with a compatible cloud/Android workflow, but iOS builds require macOS + Xcode.

## Backend
1. `cd backend`
2. Copy `.env.example` to `.env`; set a long random `JWT_SECRET` and PostgreSQL URL.
3. Create a PostgreSQL database, then run `psql "$DATABASE_URL" -f sql/001_schema.sql`.
4. `npm install`
5. `npm run dev`
6. Health check: `GET http://localhost:8080/health`

Routes:
- `POST /v1/auth/register` `{ "username":"habibi123", "displayName":"Habibi", "password":"use-a-long-password" }`
- `POST /v1/auth/login` `{ "username":"habibi123", "password":"use-a-long-password" }`
- `GET /v1/me` (Bearer token)
- `POST /v1/chats` `{ "title":"Friends", "memberIds":[] }` (Bearer token)
- `GET /v1/chats` (Bearer token)
- `GET /v1/chats/:chatId/messages` (Bearer token)

WebSocket: connect to `/ws?token=JWT`. Send `{ "type":"message.send", "chatId":"UUID", "body":"Hello" }`. Server verifies membership, stores message, and broadcasts `message.new` to connected members.

## Flutter client
1. `cd client`
2. `flutter pub get`
3. `flutter run`
4. For Android APK: `flutter build apk --release`
5. For Web: `flutter config --enable-web && flutter build web --release`
6. Windows build requires Windows host and desktop tooling; iOS requires macOS + Xcode.

The current Flutter client is a UI prototype and does not yet call the backend. Backend integration is the next client milestone.

## Safety before public launch
- Use HTTPS/WSS only in deployment.
- Add real phone OTP through an SMS provider, with rate limits and anti-abuse controls.
- Add account recovery, email/phone verification, session/device management, block/report review tools.
- Use private object storage with signed URLs and malware/type/size checks.
- Add message retention/deletion policies, backups, monitoring, audit logs and incident response.
- Do not claim end-to-end encryption until a correct protocol is implemented and independently audited.
- Never commit `.env`, database credentials, SMS keys, AI keys or payment secrets.
- Payment integration must verify purchases server-side. A parent/guardian will need to help with commercial accounts, contracts and payment provider setup.

## Versioning and ownership
Keep this folder as the master source. Create a private Git repository, commit each milestone, and tag releases (for example `v0.1.0`). Keep encrypted backups. The source belongs under the project owner's control.

## Android cloud build (added)
This starter now includes `.github/workflows/android-apk.yml`. After the project is pushed to a GitHub repository:
1. Open the repository's **Actions** tab.
2. Select **Build NOVA Android APK**.
3. Press **Run workflow** (or push to `main`).
4. When the run completes, open it and download the **NOVA-Android-APK** artifact.

The workflow generates the missing Android platform folder, fetches Flutter packages, and builds a release APK. This only packages the current client prototype; it does not turn prototype-only screens into working online services. Backend deployment, database configuration, and Flutter API/WebSocket integration remain separate tasks.
