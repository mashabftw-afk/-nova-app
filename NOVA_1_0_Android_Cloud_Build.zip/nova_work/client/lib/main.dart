import 'package:flutter/material.dart';

void main() => runApp(const NovaApp());

const _violet = Color(0xFF7658E8);
const _blue = Color(0xFF397BD8);

class NovaApp extends StatefulWidget {
  const NovaApp({super.key});
  @override
  State<NovaApp> createState() => _NovaAppState();
}

class _NovaAppState extends State<NovaApp> {
  ThemeMode _mode = ThemeMode.system;
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NOVA',
        debugShowCheckedModeBanner: false,
        themeMode: _mode,
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: _violet), scaffoldBackgroundColor: const Color(0xFFF7F7FC)),
        darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: _violet, brightness: Brightness.dark), scaffoldBackgroundColor: const Color(0xFF101018)),
        home: NovaShell(onTheme: () => setState(() => _mode = _mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark)),
      );
}

class NovaShell extends StatefulWidget {
  const NovaShell({super.key, required this.onTheme});
  final VoidCallback onTheme;
  @override
  State<NovaShell> createState() => _NovaShellState();
}

class _NovaShellState extends State<NovaShell> {
  int tab = 0;
  final pages = const [ChatsPage(), SpacesPage(), VaultPage(), ProfilePage()];
  final titles = const ['Chats', 'Spaces', 'Cloud Vault', 'Profile'];
  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 760;
    final body = Row(children: [
      if (wide) NavigationRail(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        labelType: NavigationRailLabelType.all,
        leading: Padding(padding: const EdgeInsets.symmetric(vertical: 18), child: NovaMark(size: 42)),
        destinations: const [
          NavigationRailDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: Text('Chats')),
          NavigationRailDestination(icon: Icon(Icons.workspaces_outline), selectedIcon: Icon(Icons.workspaces), label: Text('Spaces')),
          NavigationRailDestination(icon: Icon(Icons.cloud_outlined), selectedIcon: Icon(Icons.cloud), label: Text('Vault')),
          NavigationRailDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: Text('Profile')),
        ],
      ),
      if (wide) const VerticalDivider(width: 1),
      Expanded(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1000), child: pages[tab]))),
    ]);
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [NovaMark(size: 34), const SizedBox(width: 10), const Text('NOVA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.7))]),
        actions: [
          IconButton(tooltip: 'Search', onPressed: () => showSearch(context: context, delegate: NovaSearch()), icon: const Icon(Icons.search)),
          IconButton(tooltip: 'NOVA AI', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiPage())), icon: const Icon(Icons.auto_awesome_outlined)),
          IconButton(tooltip: 'Change theme', onPressed: widget.onTheme, icon: const Icon(Icons.brightness_6_outlined)),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(child: body),
      bottomNavigationBar: wide ? null : NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
        NavigationDestination(icon: Icon(Icons.workspaces_outline), selectedIcon: Icon(Icons.workspaces), label: 'Spaces'),
        NavigationDestination(icon: Icon(Icons.cloud_outlined), selectedIcon: Icon(Icons.cloud), label: 'Vault'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ]),
    );
  }
}

class NovaMark extends StatelessWidget {
  const NovaMark({super.key, this.size = 36});
  final double size;
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(borderRadius: BorderRadius.circular(size * .3), gradient: const LinearGradient(colors: [_violet, _blue])), child: Icon(Icons.bubble_chart_rounded, color: Colors.white, size: size * .65));
}

class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});
  static const chats = [
    ('NOVA Launch Team', 'Let us plan the first release.', 'Now', Icons.groups_rounded),
    ('Study Group', 'The notes are in our Space.', '10:42', Icons.school_rounded),
    ('Afnan', 'Send me the document when ready.', 'Yesterday', Icons.person_rounded),
    ('Design Circle', 'The new layout looks great!', 'Mon', Icons.palette_outlined),
  ];
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 28), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_violet, _blue])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR WORLD, CONNECTED', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.3)),
        SizedBox(height: 9), Text('More than\nmessaging.', style: TextStyle(color: Colors.white, fontSize: 30, height: 1.08, fontWeight: FontWeight.w900)),
        SizedBox(height: 9), Text('Chats, shared work and your files in one place.', style: TextStyle(color: Colors.white, fontSize: 13)),
      ])),
      const SizedBox(height: 22),
      Row(children: [Text('Recent chats', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)), const Spacer(), FilledButton.tonalIcon(onPressed: () => _newChat(context), icon: const Icon(Icons.add, size: 18), label: const Text('New chat'))]),
      const SizedBox(height: 8),
      ...chats.map((c) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 5), child: ListTile(leading: CircleAvatar(radius: 24, backgroundColor: cs.primaryContainer, child: Icon(c.$4, color: cs.onPrimaryContainer)), title: Text(c.$1, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(c.$2, maxLines: 1, overflow: TextOverflow.ellipsis), trailing: Text(c.$3, style: Theme.of(context).textTheme.labelSmall), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(title: c.$1))))),
      const SizedBox(height: 12),
      Card(elevation: 0, color: cs.secondaryContainer, child: ListTile(leading: Icon(Icons.auto_awesome, color: cs.onSecondaryContainer), title: const Text('Ask NOVA AI', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: const Text('Find, summarize and organize information.'), trailing: const Icon(Icons.arrow_forward_ios, size: 15), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiPage())))),
      const SizedBox(height: 8), const PrototypeNotice(),
    ]);
  }
  static void _newChat(BuildContext context) {
    final c = TextEditingController();
    showDialog(context: context, builder: (ctx) => AlertDialog(title: const Text('Start a chat'), content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'Username or phone number', hintText: '@username')), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () { final name = c.text.trim(); Navigator.pop(ctx); if (name.isNotEmpty) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(title: name))); }, child: const Text('Continue'))]));
  }
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key, required this.title});
  final String title;
  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final messages = <String>[];
  @override
  void dispose() { input.dispose(); super.dispose(); }
  void send() { final value = input.text.trim(); if (value.isEmpty) return; setState(() { messages.add(value); input.clear(); }); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.title), actions: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Calling will be available after the backend is connected.'))), icon: const Icon(Icons.call_outlined)), IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Video calling is planned for a later release.'))), icon: const Icon(Icons.videocam_outlined))]), body: Column(children: [const PrototypeNotice(), Expanded(child: messages.isEmpty ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.forum_outlined, size: 46), SizedBox(height: 10), Text('Start the conversation'), SizedBox(height: 4), Text('Messages in this preview stay on this device.', style: TextStyle(fontSize: 12))])) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: messages.length, itemBuilder: (_, i) => Align(alignment: Alignment.centerRight, child: Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(18)), child: Text(messages[i]))))), SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Attachments will be enabled with cloud storage.'))), icon: const Icon(Icons.attach_file)), Expanded(child: TextField(controller: input, onSubmitted: (_) => send(), decoration: InputDecoration(hintText: 'Message...', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)))), const SizedBox(width: 8), IconButton.filled(onPressed: send, icon: const Icon(Icons.send))])))]));
}

class SpacesPage extends StatelessWidget {
  const SpacesPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [Text('Work together', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height: 8), const Text('Turn a group conversation into a shared place for notes, tasks and files.'), const SizedBox(height: 18), const FeatureTile(icon: Icons.task_alt, title: 'Shared tasks', subtitle: 'Keep track of what needs to get done.'), const FeatureTile(icon: Icons.note_alt_outlined, title: 'Group notes', subtitle: 'Keep useful information together.'), const FeatureTile(icon: Icons.poll_outlined, title: 'Polls and decisions', subtitle: 'Make group decisions in one place.'), const FeatureTile(icon: Icons.calendar_month_outlined, title: 'Shared calendar', subtitle: 'Keep important dates visible to the group.'), const PrototypeNotice()]);
}

class VaultPage extends StatelessWidget {
  const VaultPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [Text('Your files, together', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height: 8), const Text('A private library for documents, photos and shared files.'), const SizedBox(height: 20), Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [const Icon(Icons.cloud_outlined, size: 52), const SizedBox(height: 10), const Text('Cloud Vault', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)), const SizedBox(height: 6), const Text('Your personal cloud library will appear here after secure storage is connected.', textAlign: TextAlign.center), const SizedBox(height: 16), FilledButton.tonalIcon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cloud upload is not connected in this preview.'))), icon: const Icon(Icons.upload_file), label: const Text('Upload file'))])), const SizedBox(height: 12), const PrototypeNotice()]);
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [const SizedBox(height: 10), const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)), const SizedBox(height: 12), Text('Your NOVA profile', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)), const SizedBox(height: 5), const Text('Your username, phone number and connected devices.', textAlign: TextAlign.center), const SizedBox(height: 22), const FeatureTile(icon: Icons.verified_user_outlined, title: 'Privacy and security', subtitle: 'Manage sessions, blocked users and account safety.'), const FeatureTile(icon: Icons.devices_outlined, title: 'Linked devices', subtitle: 'Review devices connected to your account.'), const FeatureTile(icon: Icons.workspace_premium_outlined, title: 'NOVA Premium', subtitle: 'Compare plans and manage your subscription.'), const PrototypeNotice()]);
}

class AiPage extends StatefulWidget { const AiPage({super.key}); @override State<AiPage> createState() => _AiPageState(); }
class _AiPageState extends State<AiPage> {
  final controller = TextEditingController();
  final prompts = <String>[];
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('NOVA AI')), body: Column(children: [const Expanded(child: Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.auto_awesome, size: 54), SizedBox(height: 14), Text('Your helpful AI companion', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)), SizedBox(height: 8), Text('Ask questions, summarize information and find things faster. Connect an AI service to enable real answers.', textAlign: TextAlign.center)])))), if (prompts.isNotEmpty) ...prompts.map((p) => ListTile(leading: const Icon(Icons.person_outline), title: Text(p))), SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Ask NOVA...', border: OutlineInputBorder()))), const SizedBox(width: 8), IconButton.filled(onPressed: () { if (controller.text.trim().isEmpty) return; setState(() { prompts.add(controller.text.trim()); controller.clear(); }); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI provider is not connected yet. Your prompt is shown in this preview.'))); }, icon: const Icon(Icons.send))])))]));
}

class NovaSearch extends SearchDelegate<String> {
  @override List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext context) => Center(child: Text(query.isEmpty ? 'Search chats, people and files' : 'Search will work when NOVA accounts and messages are connected.'));
  @override Widget buildSuggestions(BuildContext context) => const Padding(padding: EdgeInsets.all(20), child: Text('Search people, conversations, Spaces and files.'));
}

class FeatureTile extends StatelessWidget {
  const FeatureTile({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon; final String title; final String subtitle;
  @override Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: Icon(icon, size: 27), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle)));
}

class PrototypeNotice extends StatelessWidget {
  const PrototypeNotice({super.key});
  @override Widget build(BuildContext context) => Card(elevation: 0, color: Theme.of(context).colorScheme.surfaceContainerHighest, child: const Padding(padding: EdgeInsets.all(12), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, size: 18), SizedBox(width: 9), Expanded(child: Text('Prototype preview: accounts, live messaging, cloud upload, AI services and calls need a secure backend before public launch.', style: TextStyle(fontSize: 12)))])));
}
